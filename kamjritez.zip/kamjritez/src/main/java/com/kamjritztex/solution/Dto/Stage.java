package com.kamjritztex.solution.Dto;

public enum Stage {
           NEW,
           ACTIVE,
           ATRISK,
           CHURNED
}
